/**
 * Represents a direction of movement
 * @author Daniel Hay
 * @version 1.0
 */
public enum Direction {
    OUT,
    IN
}
